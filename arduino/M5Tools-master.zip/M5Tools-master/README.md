# M5Tools
### M5Stack Tough and Core2 tools .

# Support framework
 - Arduino for ESP32 1.0.6

# Support device
 - M5Stack Core2 / Tough

# License
 - [MIT](LICENSE)

